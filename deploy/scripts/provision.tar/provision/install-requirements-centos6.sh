#!/bin/sh

yum update

# Create users and setup permissions

# Install php 5.4+

# Install composer

# Install mysql

# Install Java 8

# Install Filebot

